var canvaswidth=520;
var canvasheight=280;

var canvas=document.getElementById('canvas');
var context=canvas.getContext('2d');
var radius=50;
var clipingRegion={x:-1,y:-1,r:radius};
canvas.width=canvaswidth;
canvas.height=canvasheight;

var image1=new Image();
image1.src="../img/001.jpg";

image1.onload=function(){
	initCanvas();
}
function initCanvas(){
	clipingRegion={x:Math.random()*(canvas.width-2*radius)+radius,y:Math.random()*(canvas.height-2*radius)+radius,r:radius};
	draw(image1,clipingRegion);
}
function draw(image1,clipingRegion){
	context.clearRect(0,0,canvas.width,canvas.height);
	context.save();
	setClipingRegion(clipingRegion);
	context.drawImage(image1,0,0);
	context.restore();
}
function setClipingRegion(clipingRegion){
	context.beginPath();
	context.arc(clipingRegion.x,clipingRegion.y,clipingRegion.r,0,2*Math.PI);
	context.clip();
	
}
function show(){
	var theAnimation=setInterval(function(){
		console.log("a");
		clipingRegion.r+=20;
		if(clipingRegion.r>2*Math.max(canvas.width,canvas.height)){
			clearInterval(theAnimation);
		}
		draw(image1,clipingRegion);
	},30);
}
function reset(){
	initCanvas();
	
}
