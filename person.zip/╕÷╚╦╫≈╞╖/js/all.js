
function showLogin(){
	layer.open({
		type:1,
		title:"登录",
		area:['395px','300px'],
		content:$('#loginbox')
	});
	console.log("A");
}
function Login(){
	var txtUserName=$.trim($('#txtUserName').val());
	var txtPwd=$.trim($('#txtpwd').val());
	if(txtUserName==""||txtPwd==""){
		layer.alert('用户名或密码不能为空',{
			title:"提示",
			icon:6
		});
	}
}
function showRegist(){
	layer.open({
		type:1,
		title:"注册",
		area:['395px','400px'],
		content:$('#reg')
	});
}
function Regist(){
	var userName=$.trim($('#userName').val());
	var pwd=$.trim($('#pwd').val());
	var repwd=$.trim($('#repwd').val());
	if(userName==''||pwd==''||repwd==''){
		layer.alert('用户名或密码不能为空',{
			icon:5
		});
	}
}