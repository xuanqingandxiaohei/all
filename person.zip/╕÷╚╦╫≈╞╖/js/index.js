var i=0;
var time;
$(function(){
	$("#image").hover(function(){
		$(".ig").show();
	},function(){
		$(".ig").hide();
	});

	$(".img").eq(0).show().siblings().hide();
	showTime();
		$(".ing").hover(function(){
			clearInterval(time);
			i=$(this).index();
			show();
		},function(){
			showTime();
			
		});
	$(".ign1").click(function(){
		clearInterval(time);
		if(i==0){
			i=6;
		}
		i--;
		show();
		showTime();
	});
	$(".ign2").click(function(){
		clearInterval(time);
		if(i==6){
			i=-1;
		}
		i++;
		show();
		showTime();
	});
	
});
function show(){
	$(".img").eq(i).fadeIn(300).siblings().fadeOut(300);
	$(".ing").eq(i).addClass("ingg").siblings().removeClass("ingg");
}
function showTime(){
	time=setInterval(function(){
			
			i++;
			if(i==6){
				i=0;
			}
			show();
		},4000);
}
