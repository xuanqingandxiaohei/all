var canvas=document.getElementById('canvas');
var context=canvas.getContext('2d');
var image1=new Image();
var isMoveDown=false;
var offCanvas=document.getElementById('offCanvas');
var offContext=offCanvas.getContext('2d');
var scale;
			
window.onload=function(){
	canvas.width=300;
	canvas.height=415;
	image1.src='../img/gqj_01.jpg';
	image1.onload=function(){
	offCanvas.width=image1.width;
	offCanvas.height=image1.height;
	scale=offCanvas.width/canvas.width;
	context.drawImage(image1,0,0,canvas.width,canvas.height);
	offContext.drawImage(image1,0,0);
					
	}
}
			function windowToCanvas(x,y){
				var bbox=canvas.getBoundingClientRect();
				return {x:x-bbox.left,y:y-bbox.top}
			}
			
			canvas.onmousedown=function(e){
				e.preventDefault();
				var point=windowToCanvas(e.clientX,e.clientY);
				console.log(point.x,point.y);
				isMoveDown=true;
				drawCanvasWithMagnifier(true,point);
				
			}
			canvas.onmousemove=function(e){
				e.preventDefault();
				if(isMoveDown){
					var point=windowToCanvas(e.clientX,e.clientY);
					console.log(point.x,point.y);
					drawCanvasWithMagnifier(true,point);
				}
				
			}
			canvas.onmouseup=function(e){
				e.preventDefault();
				isMoveDown=false;
				drawCanvasWithMagnifier(false);
			}
			canvas.onmouseout=function(e){
				e.preventDefault();
				isMoveDown=false;
				drawCanvasWithMagnifier(false);
				
			}
			function drawCanvasWithMagnifier(isShowMagnifier,point){
				context.clearRect(0,0,canvas.width,canvas.height);
				context.drawImage(image1,0,0,canvas.width,canvas.height);
				if(isShowMagnifier){
					drawMagnifier(point);
				}
				
			}
			function drawMagnifier(point){
				var imageLG_cx=point.x*scale;
				var imageLG_cy=point.y*scale;
				var mr=50;
				var sx=imageLG_cx-mr;
				var sy=imageLG_cy-mr;
				var dx=point.x-mr;
				var dy=point.y-mr;
				context.save();
				context.lineWidth=3.0;
				context.strokeStyle="rgb(107,185,121)";
				context.beginPath();
				
				context.arc(point.x,point.y,mr,0,2*Math.PI);
				context.stroke();
				context.clip();
				context.drawImage(offCanvas,sx,sy,2*mr,2*mr,dx,dy,2*mr,2*mr);
				context.restore();
}