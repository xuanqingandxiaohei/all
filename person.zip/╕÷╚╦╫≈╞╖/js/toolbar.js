//滚动
var scrollto=(function(){
	function ScrollTo(opts){
		this.opts=$.extend({},ScrollTo.DEFAULTS,opts);
		this.$el=$('html,body');
	}
	
	ScrollTo.prototype.move=function(){
		var opts=this.opts,
			dest=opts.dest;
		if ($(window).scrollTop() != dest) {
			if(!this.$el.is(':animated')){
				this.$el.animate({
				scrollTop:dest
				},opts.speed);
			}
		}
	};
	ScrollTo.prototype.go=function(){
		var dest=this.opts;
		if ($(window).scrollTop() != dest) {
			this.$el.scrollTop(dest);
		}
	}
	ScrollTo.DEFAULTS={
		dest:0,
		speed:800
		
	};
	return {
		ScrollTo:ScrollTo
	};
})();
//返回顶部
var backtop=(function(){
	function BackTop(el,opts){
		this.opts=$.extend({},BackTop.DEFAULTS,opts);
		this.$el=$(el);
		this.scroll=new scrollto.ScrollTo({
			dest:0,
			speed:this.opts.speed
		});
		this._checkPosition();
		if(this.opts.mode == 'move'){
			this.$el.on('click',$.proxy(this._move,this));
		}else{
			this.$el.on('click',$.proxy(this._go,this));
		}
		
		$(window).on('scroll',$.proxy(this._checkPosition,this));
	}
	BackTop.DEFAULTS={
		mode:'move',
		pos:$(window).height(),
		speed:800
	};
	BackTop.prototype._move=function(){
		this.scroll.move();
	}
	BackTop.prototype._go=function(){
		this.scroll.go();
	}
	BackTop.prototype._checkPosition=function(){
		var $el=this.$el;
		if($(window).scrollTop() > this.opts.pos){
			$el.fadeIn();
			$('.toolbar-item:nth-last-child(2)').css('border-bottom',1+'px solid #d0d6d9');
		}else{
			$el.fadeOut();
			$('.toolbar-item:nth-last-child(2)').css('border-bottom',0);
		}
	}
//	jQuery插件
	$.fn.extend({
		backtop:function(opts){
			return this.each(function(){
				new BackTop(this,opts);
			});
		}
	});
	return {
		BackTop:BackTop
	};
})();
$("#backTop").backtop();



//$(function(){
//	$('#backTop').on('click',move);
//	$(window).on('scroll',function(){
//		checkPosition($(window).height());
//	});
//	checkPosition($(window).height());
//});
//
//function move(){
//	$('html,body').animate({
//		scrollTop:0
//	},800);
//	console.log("a");
//}
//function go(){
//	$('html,body').scrollTop(0);
//}
//function checkPosition(pos){
//	if ($(window).scrollTop() > pos) {
//		$('#backTop').fadeIn();
//		$('.toolbar-item:nth-last-child(2)').css('border-bottom',1+'px solid #d0d6d9');
//	} else{
//		$('#backTop').fadeOut();
//		$('.toolbar-item:nth-last-child(2)').css('border-bottom',0);
//	}
//	
//}

